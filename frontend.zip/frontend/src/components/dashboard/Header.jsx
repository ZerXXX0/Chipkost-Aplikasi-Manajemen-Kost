import React from 'react';
import { useAuth } from '../../context/AuthContext';

const Header = () => {
  const { user } = useAuth();
  const displayName = user?.first_name || 'User';
  const roleLabel = user?.role === 'admin' ? 'Pemilik' : (user?.role || 'Pengguna');

  return (
    <header className="w-full bg-cyan-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded bg-white/20 flex items-center justify-center font-bold">C</div>
          <span className="font-semibold tracking-wide">Chipkost</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right leading-tight">
            <div className="text-sm">{displayName}</div>
            <div className="text-xs opacity-90">{roleLabel}</div>
          </div>
          <img
            src={`https://i.pravatar.cc/40?u=${encodeURIComponent(displayName)}`}
            alt="avatar"
            className="h-9 w-9 rounded-full ring-2 ring-white/50"
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
