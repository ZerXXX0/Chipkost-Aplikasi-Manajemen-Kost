import React from 'react';

const InfoCard = ({ imageSrc, title, description, onClick }) => {
  return (
    <div className="bg-white rounded-md shadow-md overflow-hidden flex flex-col">
      <div className="h-40 w-full bg-gray-200 overflow-hidden">
        {imageSrc ? (
          <img src={imageSrc} alt={title} className="h-full w-full object-cover" />
        ) : (
          <div className="h-full w-full flex items-center justify-center text-gray-400 text-sm">No Image</div>
        )}
      </div>
      <div className="p-5 flex flex-col flex-1">
        <h3 className="text-lg font-semibold mb-2 text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600 leading-relaxed flex-1">{description}</p>
        <div className="mt-4">
          <button
            onClick={onClick}
            className="px-5 py-2 rounded-full text-sm font-medium bg-cyan-600 hover:bg-cyan-700 text-white transition-colors"
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default InfoCard;
