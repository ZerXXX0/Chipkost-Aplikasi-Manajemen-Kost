import React from 'react';

const NavButton = ({ active, children }) => (
  <button
    className={[
      'px-6 py-2 rounded-full text-sm font-medium transition-colors',
      active ? 'bg-white text-gray-900 shadow' : 'text-white/90 hover:bg-white/10'
    ].join(' ')}
  >
    {children}
  </button>
);

const Navigation = () => {
  return (
    <nav className="w-full bg-gradient-to-b from-cyan-600 to-cyan-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-6">
        <NavButton active>Home</NavButton>
        <NavButton>Fitur</NavButton>
        <NavButton>Customer Service</NavButton>
      </div>
    </nav>
  );
};

export default Navigation;
