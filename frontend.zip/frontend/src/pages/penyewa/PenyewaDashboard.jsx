import DashboardPage from '../admin/DashboardPage';

const PenyewaDashboard = () => {
  return <DashboardPage />;
};

export default PenyewaDashboard;
