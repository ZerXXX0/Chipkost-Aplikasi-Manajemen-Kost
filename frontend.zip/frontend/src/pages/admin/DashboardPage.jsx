import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Header from '../../components/dashboard/Header';
import Navigation from '../../components/dashboard/Navigation';
import QuickAccessSection from '../../components/dashboard/QuickAccessSection';
import { LogOut } from 'lucide-react';

const DashboardPage = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-100/60 to-white flex flex-col">
      <Header />
      <Navigation />
      <QuickAccessSection />
      {/* Logout button fixed at bottom right */}
      <div className="flex-1" />
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium shadow-lg"
        >
          <LogOut className="h-4 w-4" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default DashboardPage;
