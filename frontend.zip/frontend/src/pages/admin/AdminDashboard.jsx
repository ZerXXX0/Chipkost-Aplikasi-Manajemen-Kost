import DashboardPage from './DashboardPage';

const AdminDashboard = () => {
  return <DashboardPage />;
};

export default AdminDashboard;
