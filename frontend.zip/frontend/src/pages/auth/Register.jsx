import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Login.css'; // Reusing the same CSS

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    password2: '',
    first_name: '',
    last_name: '',
    phone_number: '',
    role: 'penyewa',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.password2) {
      setError('Password tidak sama.');
      return;
    }

    setLoading(true);

    try {
      const data = await register(formData);

      // After successful registration we send the user back to the login page
      // so they can authenticate explicitly.
      navigate('/login');
    } catch (err) {
      const errorMessages = [];
      
      // Handle different error formats
      if (typeof err === 'object' && err !== null) {
        // Handle field-specific errors
        Object.keys(err).forEach(key => {
          if (Array.isArray(err[key])) {
            errorMessages.push(`${key}: ${err[key].join(', ')}`);
          } else if (typeof err[key] === 'string') {
            errorMessages.push(`${key}: ${err[key]}`);
          }
        });
      }
      
      setError(errorMessages.length > 0 ? errorMessages.join(' | ') : 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      {/* Decorative dots - top right */}
      <div className="dots dots-top-right">
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
      </div>

      {/* Main form */}
      <div className="login-form" style={{ maxWidth: '500px' }}>
          <h2 style={{ textAlign: 'center', marginBottom: '24px', color: '#333' }}>
            Create Account
          </h2>
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <input
              type="text"
              name="username"
              placeholder="Username"
              value={formData.username}
              onChange={handleChange}
              className="input-field"
              required
            />

            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              className="input-field"
              required
            />

            <input
              type="text"
              name="first_name"
              placeholder="First Name"
              value={formData.first_name}
              onChange={handleChange}
              className="input-field"
              required
            />

            <input
              type="text"
              name="last_name"
              placeholder="Last Name"
              value={formData.last_name}
              onChange={handleChange}
              className="input-field"
              required
            />

            <input
              type="tel"
              name="phone_number"
              placeholder="Phone Number"
              value={formData.phone_number}
              onChange={handleChange}
              className="input-field"
            />

            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="input-field"
            >
              <option value="penyewa">Penyewa</option>
            </select>
          </div>

          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            className="input-field"
            required
          />

          <input
            type="password"
            name="password2"
            placeholder="Confirm Password"
            value={formData.password2}
            onChange={handleChange}
            className="input-field"
            required
          />

          {error && (
            <div className="error-message" style={{ color: 'red', fontSize: '14px' }}>
              {error}
            </div>
          )}

          <button type="submit" className="login-button" disabled={loading}>
            {loading ? 'Creating Account...' : 'Sign Up'}
          </button>
        </form>

        <div className="form-links">
          <p className="signup-text">
            Already have an account? <a href="/login" className="signup-link">Login</a>
          </p>
        </div>
      </div>

      {/* Decorative dots - bottom left */}
      <div className="dots dots-bottom-left">
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
      </div>
    </div>
  );
}
