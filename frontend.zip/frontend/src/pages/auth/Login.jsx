import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Login.css';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const data = await login(username, password);
      
      if (data?.user?.role === 'admin') {
        navigate('/admin');
      } else {
        // backend and other parts of app use 'penyewa' route
        navigate('/penyewa');
      }
    } catch (err) {
      setError(typeof err === 'string' ? err : 'Login gagal.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      {/* Decorative dots - top right */}
      <div className="dots dots-top-right">
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
      </div>

      {/* Main form */}
      <div className="login-form">
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="input-field"
            required
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field password-input"
            required
          />

          {error && (
            <div className="error-message" style={{ color: 'red', fontSize: '14px' }}>
              {error}
            </div>
          )}

          <button type="submit" className="login-button" disabled={loading}>
            {loading ? 'Loading...' : 'Login'}
          </button>
        </form>

        <div className="form-links">
          <a href="#forgot" className="forgot-password">
            Forget Password?
          </a>
          <p className="signup-text">
            Not a member yet? <a href="/register" className="signup-link">Sign Up</a>
          </p>
        </div>
      </div>

      {/* Decorative dots - bottom left */}
      <div className="dots dots-bottom-left">
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
      </div>
    </div>
  );
}