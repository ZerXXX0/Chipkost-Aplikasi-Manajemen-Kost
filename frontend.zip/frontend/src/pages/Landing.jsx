import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function Landing() {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 3;

  const quickAccessItems = [
    {
      id: 1,
      title: 'Registrasi Penyewa',
      description: 'Lorem ipsum dolor sit amet pretium consectetur adipiscing elit. Lorem consectetur adipiscing elit.',
      imageSrc: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=60'
    },
    {
      id: 2,
      title: 'Komplain Penghuni',
      description: 'Kost Pesbal Mandiri Sejahtera - CiptoXHadiX69: Baru semalam tinggal disini udah hilang aja tabung gas sama motorku emang pompa ni dah glia kali...',
      imageSrc: 'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    },
    {
      id: 3,
      title: 'Laporan Keuangan',
      description: 'Kost Mustika Bujangan - Pemasukan Bulan Januari Rp -9.000.000 ...',
      imageSrc: 'https://images.unsplash.com/photo-1545239705-221baffbfa34?auto=format&fit=crop&w=800&q=60'
    },
    {
      id: 4,
      title: 'Tagihan Bulanan',
      description: 'Periksa dan kelola invoice serta status pembayaran terbaru.',
      imageSrc: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=60'
    },
    {
      id: 5,
      title: 'Verifikasi Pembayaran',
      description: 'Konfirmasi bukti pembayaran dari penyewa dan update status.',
      imageSrc: 'https://images.unsplash.com/photo-1558640473-9d2a7deb7f62?auto=format&fit=crop&w=800&q=60'
    },
    {
      id: 6,
      title: 'Monitoring Kamar',
      description: 'Pantau okupansi kamar dan status perbaikan atau perawatan.',
      imageSrc: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=800&q=60'
    }
  ];

  const totalPages = Math.ceil(quickAccessItems.length / itemsPerPage);
  const startIdx = (currentPage - 1) * itemsPerPage;
  const endIdx = startIdx + itemsPerPage;
  const visibleItems = quickAccessItems.slice(startIdx, endIdx);

  const handleViewDetails = (itemId) => {
    navigate('/login');
  };

  const QuickAccessCard = ({ item }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
      <div className="h-40 w-full bg-gray-200 overflow-hidden">
        <img src={item.imageSrc} alt={item.title} className="h-full w-full object-cover" />
      </div>
      <div className="p-5">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
        <p className="text-sm text-gray-600 mb-4 line-clamp-3">{item.description}</p>
        <button
          onClick={() => handleViewDetails(item.id)}
          className="w-full px-4 py-2 rounded-full text-sm font-medium bg-cyan-600 hover:bg-cyan-700 text-white transition-colors"
        >
          View Details
        </button>
      </div>
    </div>
  );

  const PaginationButton = ({ number, isActive, onClick }) => (
    <button
      onClick={onClick}
      className={`h-9 w-9 rounded-md font-medium transition-colors ${
        isActive
          ? 'bg-cyan-600 text-white'
          : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
      }`}
    >
      {number}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-100/60 to-white">
      {/* Header */}
      <header className="w-full bg-cyan-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded bg-white/20 flex items-center justify-center font-bold">C</div>
            <span className="font-semibold tracking-wide">Chipkost</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/login')}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-white/20 hover:bg-white/30 transition-colors"
            >
              Login
            </button>
            <button
              onClick={() => navigate('/register')}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-white text-cyan-600 hover:bg-gray-100 transition-colors"
            >
              Sign Up
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="w-full bg-gradient-to-b from-cyan-600 to-cyan-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-6">
          <button className="px-6 py-2 rounded-full text-sm font-medium bg-white text-gray-900 shadow">
            Home
          </button>
          <button className="px-6 py-2 rounded-full text-sm font-medium text-white/90 hover:bg-white/10 transition-colors">
            Fitur
          </button>
          <button className="px-6 py-2 rounded-full text-sm font-medium text-white/90 hover:bg-white/10 transition-colors">
            Customer Service
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Welcome Section */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Selamat Datang, User</h1>
          <h2 className="text-xl font-medium text-gray-800">Quick Access</h2>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {visibleItems.map(item => (
            <QuickAccessCard key={item.id} item={item} />
          ))}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            className="h-9 w-9 flex items-center justify-center rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
            <PaginationButton
              key={page}
              number={page}
              isActive={page === currentPage}
              onClick={() => setCurrentPage(page)}
            />
          ))}

          <button
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            className="h-9 w-9 flex items-center justify-center rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </section>

      {/* Footer Info */}
      <div className="bg-gradient-to-b from-transparent to-cyan-50 py-8 text-center text-gray-600 text-sm">
        <p>Kelola kos Anda dengan mudah dan efisien bersama Chipkost</p>
      </div>
    </div>
  );
}

